const columns = [
    {
        field: 'topic_id',
        header: 'Topic ID',
        width: '120px',
        visible: true,
        sortable: false
    },
    {
        field: 'code',
        header: 'Code',
        width: '150px',
        visible: true,
        sortable: true
    },
    // ... rest of existing columns
] 