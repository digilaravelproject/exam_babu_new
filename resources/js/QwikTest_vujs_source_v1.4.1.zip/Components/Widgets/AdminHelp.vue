<template>
    <div class="w-full rounded shadow-lg p-5 bg-green-700">
        <h1 class="text-lg font-bold leading-7 pt-6 text-white">{{ __('To Teach is To Learn Twice Over.') }}</h1>
        <p class="pt-4 text-xs leading-5 ltr:pr-12 rtl:pl-12 text-white">{{ __('admin_help_message') }}</p>
        <div class="pt-7 flex items-center justify-end">
            <a href="https://nearchip.gitbook.io/qwiktest" target="_blank"
                class="text-green-700 rounded-sm bg-gray-50 focus:ring-2 focus:ring-offset-2 focus:ring-orange-900 focus:outline-none focus:opacity-90 hover:opacity-90 p-2 text-xs font-medium leading-3">View Docs</a>
        </div>
    </div>
</template>
