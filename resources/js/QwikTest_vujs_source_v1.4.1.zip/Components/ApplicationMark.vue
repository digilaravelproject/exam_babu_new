<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 50 50">
        <g id="Icon" transform="translate(13 344)">
            <g id="circle" transform="translate(-29 -361.14)">
                <circle id="bg_circle" cx="25" cy="25" r="25" transform="translate(16 17.14)" fill="#25c16f"/>
                <path id="white_ring" d="M20,0A19.969,19.969,0,0,1,37.151,30.248c-.712,1.229-2.946,1.654-4.181,2.926-1.2,1.235-1.426,3.291-3.258,4.338A20.011,20.011,0,1,1,20,0Z" transform="translate(21 22.14)" fill="#fff"/>
                <circle id="green_ring" cx="15" cy="15" r="15" transform="translate(26 27.14)" fill="#25c16f"/>
            </g>
            <g id="cursor" transform="matrix(1, -0.017, 0.017, 1, 10.797, -319.593)">
                <path id="right" d="M10.286,23.465a.687.687,0,0,1-.63-.413L.057.962a.687.687,0,0,1,.9-.9l22.09,9.6a.687.687,0,0,1-.073,1.288L16.249,13A4.885,4.885,0,0,0,13,16.249l-2.058,6.73a.687.687,0,0,1-.619.485Z" transform="translate(0 0)" fill="#fff"/>
                <path id="left" d="M27.244,9.657,5.154.058A.688.688,0,0,0,4.394.2h0L18.412,14.221A4.887,4.887,0,0,1,20.441,13l6.73-2.058a.687.687,0,0,0,.073-1.288Z" transform="translate(-4.192 -0.001)" fill="#fff"/>
            </g>
        </g>
    </svg>
</template>
